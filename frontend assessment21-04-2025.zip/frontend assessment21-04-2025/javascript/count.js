//count vowels
let vowels=(a,e,i,o,u);
console.log(vowels)

function countVowels(){
let str=vowels.countVowels("hello World");
  console.log(str);

}

//fattenand sort
let arr=t([[3, 2, 1], [4, 5, 2], [1, 6]])

let str =arr.sort(ascn);
console.log(str);

const expenses = [
    { category: "Food", amount: 120 },
    { category: "Travel", amount: 300 },
    { category: "Food", amount: 80 },
    { category: "Bills", amount: 200 },
{ category: "Travel", amount: 100 },
];

function  getCategorySummary(expenses) {
    console.log(expenses.category);
}
